import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { BranchesComponent } from './branches.component';
import { BranchlistComponent } from './branchlist.component';
import { CompanyComponent } from './company.component';
import { CompanylistComponent } from './companylist.component';

const routes: Routes = [    
    {
        path: 'companylist',
        component: CompanylistComponent
    },
    {
        path: 'branchlist',
        component: BranchlistComponent
    },
    {
        path: 'createcompany',
        component: CompanyComponent
    },
    {
        path: 'createbranch',
        component: BranchesComponent
    },
    
];


// const routes: Routes = [
//     {
//       path: '',
//       component: CompanylistComponent,
//       children: [
//         {
//           path: '',
//           loadChildren: () => import('@app/content/pages/pages.module').then(m => m.PagesModule)
//         },
//         {
//           path: 'home',
//           loadChildren: () => import('@app/content/pages/pages.module').then(m => m.PagesModule)
//         }
//       ]
//     }
//   ];


@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class MasterRoutingModule { }
