import { Component, OnInit } from "@angular/core";

@Component({
  selector: "app-departmentlist",
  templateUrl: "./departmentlist.component.html",
  
})

export class DepartmentlistComponent implements OnInit {
  
  constructor() { 

  }

  ngOnInit() {

  }
}
