import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'my-apps',
  templateUrl: './apps.component.html',
  styleUrls: ['./apps.component.scss']
})
export class AppsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
