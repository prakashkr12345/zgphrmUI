import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'gx-invite-friends-card',
  templateUrl: './gx-invite-friends-card.component.html',
  styleUrls: ['./gx-invite-friends-card.component.scss']
})
export class GxInviteFriendsCardComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
