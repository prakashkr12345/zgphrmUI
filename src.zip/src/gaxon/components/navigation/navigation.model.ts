export interface NavigationModelInterface
{
  navigation: any[];
}

